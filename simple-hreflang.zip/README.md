# Simple Hreflang

Contributors: User256
Tags: hreflang, sitemap, multilingual, translation groups
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight WordPress plugin for small sites that want to group equivalent pages and publish hreflang relationships in a standalone XML sitemap.

## Features

- Add a translation group, language, optional region, and x-default per page
- Manage plugin settings under **Settings > Simple Hreflang**
- Generate a dedicated sitemap at `/simple-hreflang-sitemap.xml`
- Output language-only hreflang values like `en` when no region is selected
- Output language-region values like `en-US` when both are selected

## Install

1. Upload the `simple-hreflang` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress
3. Visit **Settings > Permalinks** and click save once if the sitemap URL does not load immediately

## Usage

1. Edit a page
2. Fill in **Translation Group** with the same value on equivalent pages
3. Select a language
4. Optionally select a region
5. Optionally mark one page in the group as **x-default**
6. Publish the pages
7. Open `/simple-hreflang-sitemap.xml`

## Notes

- Only published pages are included in the sitemap
- Groups with fewer than the configured minimum size are skipped
- Duplicate hreflang codes inside the same group are skipped from the sitemap
- Only one x-default page is allowed per group
